import React from 'react';
import './Footer.css';


class Footer extends React.Component {
  

  render() {
    return (
      <div class="footer-copyright text-center ">© 2018 Copyright:
      <a href="/"> Handy Helper</a>
        </div>
    )};
};

export default Footer
